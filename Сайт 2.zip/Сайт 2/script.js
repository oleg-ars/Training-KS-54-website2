function tovar1() {
    window.location.href = "Товар.html";
}

function tovar2() {
    window.location.href = "Товар_фото.html";
}

function tovar3() {
    window.location.href = "Товар_fl.html";
}

function tovar4() {
    window.location.href = "Товар_премьер.html";
}

function entrance() {
    window.location.href = "Вход.html";
}

function registration() {
    window.location.href = "Регистрация.html";
}

function software_products() {
    window.location.href = "Товары.html";
}

function software_products2() {
    window.location.href = "Товары_2.html";
}

function software_products3() {
    window.location.href = "Товары_3.html";
}

function software_products4() {
    window.location.href = "Товары_4.html";
}

function index() {
    window.location.href = "index.html";
}

function basket() {
    window.location.href = "Корзина.html";
}

function reviews() {
    window.location.href = "Отзовы.html";
}

function contacts() {
    window.location.href = "Контакты.html";
}